<?php 
 
 $con = mysqli_connect("localhost","root","","whxpykvf_assignment_management") or die("Couldn't connect");

?>